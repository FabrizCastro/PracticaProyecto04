#pragma once
#include <iostream>
#include <fstream>
#include <vector>
#include <string>
//#include "funcionesaux.h"
using namespace std;
using namespace System;

class BasedeDatos
{
private:
	fstream archivoUsuario;
	fstream archivoCancion;
	vector<string>Vec_string;
	bool cancion_encontrada;
	string autor;
	
	vector<string> split(string str)
	{
		int posInicial = 0;
		int posEncontrada = 0;
		string cSeparado; //cadena 
		vector<string> resultado;
		char separador = '\t';


		//  (0)Back in Black (10)	ACDC
		while ([](int x) {if (x >= 0) return true; else return false; }(posEncontrada)) { 
			posEncontrada = str.find(separador, posInicial);// si no encuentra devuelve -1
				//10					10          0
			cSeparado = str.substr(posInicial, posEncontrada - posInicial);
			//                        0              10           0
			posInicial = posEncontrada + 1;
			resultado.push_back(cSeparado); // hecho con vectores
		}

		return resultado;
	}

public:
	BasedeDatos() 
	{

	archivoUsuario.open("Usuarios.txt", ios::trunc | ios::out);
	cancion_encontrada = false;
	};
	
	void EscribirDatosUsuarios(string dato) 
	{		
		archivoUsuario << dato<<endl;	
	};


	string LeerCanciones(string nombreCancion) 
	{
		string cadena;
		archivoCancion.open("Canciones.txt", ios::in);
		archivoCancion.seekg(0);
		while (!archivoCancion.eof())
		{
			getline(archivoCancion, cadena);
			Vec_string = split(cadena);
			if (Vec_string[0]==nombreCancion)
			{
				cout << "Busqueda realizada\n";
				cancion_encontrada = true;
				autor = Vec_string[1];
				archivoCancion.close();
				return cadena;
				
			}
			else
				cancion_encontrada = false;
		

		}
		archivoCancion.close();
		return "No se encontro";
		
	}

	bool retornar_cancion()
	{
		return cancion_encontrada;
	}


	string retornar_autor()
	{
		return autor;
	}
};

